// // tailwind.config.js
// /** @type {import('tailwindcss').Config} */
// module.exports = {
//   content: ['./app/**/*.{js,jsx}', './components/**/*.{js,jsx}'],
//   theme: {
//     extend: {
//       gridTemplateColumns: {
//         12: 'repeat(12, minmax(0, 1fr))',
//       },
//     },
//   },
//   plugins: [],
// safelist: [
//   {
//     pattern: /col-span-(3|6|12)/,
//   },
//   {
//     pattern: /row-span-(3|6)/,
//   },
// ],
// }
