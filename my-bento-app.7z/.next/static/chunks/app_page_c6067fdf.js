(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_e4d17f30._.js",
  "static/chunks/node_modules_e84b91bb._.js",
  "static/chunks/styles_d8db0fbf._.css"
],
    source: "dynamic"
});
