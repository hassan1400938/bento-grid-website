(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/data/widgets.json (json)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v(JSON.parse("[{\"id\":1,\"title\":\"Dodgeball\",\"color\":\"bg-orange-500\",\"emoji\":\"🏐\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-2\"},{\"id\":2,\"title\":\"WhatsApp\",\"color\":\"bg-green-500\",\"emoji\":\"💬\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-2\"},{\"id\":3,\"title\":\"Schedule\",\"color\":\"bg-white text-black\",\"emoji\":\"📅\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-2\"},{\"id\":4,\"title\":\"Clinic Info\",\"color\":\"bg-white text-black\",\"emoji\":\"📋\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-4\"},{\"id\":5,\"title\":\"Discord\",\"color\":\"bg-indigo-600\",\"emoji\":\"💻\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-2\"},{\"id\":6,\"title\":\"Pricing\",\"color\":\"bg-orange-400\",\"emoji\":\"💳\",\"col\":\"col-span-6 md:col-span-8 lg:col-span-6\",\"row\":\"row-span-2\"},{\"id\":7,\"title\":\"Stats\",\"color\":\"bg-purple-500\",\"emoji\":\"📈\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-2\"},{\"id\":8,\"title\":\"Coach\",\"color\":\"bg-blue-600\",\"emoji\":\"🧑‍🏫\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-2\"},{\"id\":9,\"title\":\"Shop\",\"color\":\"bg-pink-500\",\"emoji\":\"🛍️\",\"col\":\"col-span-6 md:col-span-8 lg:col-span-6\",\"row\":\"row-span-2\"},{\"id\":10,\"title\":\"Photos\",\"color\":\"bg-yellow-400\",\"emoji\":\"📸\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-2\"},{\"id\":11,\"title\":\"FAQs\",\"color\":\"bg-gray-200 text-black\",\"emoji\":\"❓\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-4\"},{\"id\":12,\"title\":\"Contact\",\"color\":\"bg-blue-300\",\"emoji\":\"📞\",\"col\":\"col-span-6 md:col-span-8 lg:col-span-6\",\"row\":\"row-span-2\"},{\"id\":13,\"title\":\"Stats\",\"color\":\"bg-purple-500\",\"emoji\":\"📈\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-2\"},{\"id\":14,\"title\":\"Coach\",\"color\":\"bg-blue-600\",\"emoji\":\"🧑‍🏫\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-2\"},{\"id\":15,\"title\":\"Shop\",\"color\":\"bg-pink-500\",\"emoji\":\"🛍️\",\"col\":\"col-span-6 md:col-span-8 lg:col-span-6\",\"row\":\"row-span-2\"},{\"id\":16,\"title\":\"Photos\",\"color\":\"bg-yellow-400\",\"emoji\":\"📸\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-2\"},{\"id\":17,\"title\":\"FAQs\",\"color\":\"bg-gray-200 text-black\",\"emoji\":\"❓\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-4\"},{\"id\":18,\"title\":\"Contact\",\"color\":\"bg-blue-300\",\"emoji\":\"📞\",\"col\":\"col-span-6 md:col-span-8 lg:col-span-6\",\"row\":\"row-span-2\"}]"));}}),
"[project]/app/page.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>HomePage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$gsap$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/gsap/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$widgets$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/data/widgets.json (json)");
(()=>{
    const e = new Error("Cannot find module '../components/Widget'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function HomePage() {
    _s();
    const [visibleCount, setVisibleCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(6);
    const loadMoreRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const tileRefs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])([]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HomePage.useEffect": ()=>{
            const el = tileRefs.current[visibleCount - 1];
            if (el) {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$gsap$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].fromTo(el, {
                    opacity: 0,
                    y: 30
                }, {
                    opacity: 1,
                    y: 0,
                    duration: 1.2,
                    ease: 'power3.out'
                });
            }
        }
    }["HomePage.useEffect"], [
        visibleCount
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HomePage.useEffect": ()=>{
            if (!loadMoreRef.current || visibleCount >= __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$widgets$2e$json__$28$json$29$__["default"].length) return;
            const observer = new IntersectionObserver({
                "HomePage.useEffect": (entries)=>{
                    if (entries[0].isIntersecting) {
                        setVisibleCount({
                            "HomePage.useEffect": (prev)=>Math.min(prev + 1, __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$widgets$2e$json__$28$json$29$__["default"].length)
                        }["HomePage.useEffect"]);
                    }
                }
            }["HomePage.useEffect"], {
                rootMargin: '200px'
            });
            observer.observe(loadMoreRef.current);
            return ({
                "HomePage.useEffect": ()=>observer.disconnect()
            })["HomePage.useEffect"];
        }
    }["HomePage.useEffect"], [
        visibleCount
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "container min-h-screen bg-[#f5e2cf] text-black px-20 lg:px-96 py-8  lg:py-48",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid grid-cols-6 md:grid-cols-8 lg:grid-cols-12 auto-rows-[72px] gap-4 grid-flow-dense max-w-screen-xl mx-auto",
            children: [
                __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$widgets$2e$json__$28$json$29$__["default"].slice(0, visibleCount).map((w, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Widget, {
                        title: w.title,
                        emoji: w.emoji,
                        color: w.color,
                        col: w.col,
                        row: w.row,
                        innerRef: (el)=>tileRefs.current[i] = el
                    }, w.id, false, {
                        fileName: "[project]/app/page.js",
                        lineNumber: 49,
                        columnNumber: 11
                    }, this)),
                visibleCount < __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$widgets$2e$json__$28$json$29$__["default"].length && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    ref: loadMoreRef,
                    className: "col-span-12 h-1"
                }, void 0, false, {
                    fileName: "[project]/app/page.js",
                    lineNumber: 61,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/page.js",
            lineNumber: 47,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/page.js",
        lineNumber: 46,
        columnNumber: 5
    }, this);
}
_s(HomePage, "hFCqhJMhGd9K19ej3pZhlkSFg+8=");
_c = HomePage;
var _c;
__turbopack_context__.k.register(_c, "HomePage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=_5b2aaf8c._.js.map