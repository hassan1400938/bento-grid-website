__turbopack_load_page_chunks__("/privacy-policy", [
  "static/chunks/node_modules_next_dist_4f3d469a._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_2a5cf4bb._.js",
  "static/chunks/[root-of-the-server]__c3ffc3d5._.js",
  "static/chunks/styles_PrivacyPolicy_module_d065a1b5.css",
  "static/chunks/pages_privacy-policy_5771e187._.js",
  "static/chunks/pages_privacy-policy_20a26e7d._.js"
])
