__turbopack_load_page_chunks__("/youth", [
  "static/chunks/node_modules_next_dist_4f3d469a._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_2a5cf4bb._.js",
  "static/chunks/[root-of-the-server]__1c8f4eec._.js",
  "static/chunks/styles_Youth_module_9aa56290.css",
  "static/chunks/pages_youth_5771e187._.js",
  "static/chunks/pages_youth_94161278._.js"
])
