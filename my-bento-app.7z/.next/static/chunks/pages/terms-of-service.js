__turbopack_load_page_chunks__("/terms-of-service", [
  "static/chunks/node_modules_next_dist_4f3d469a._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_2a5cf4bb._.js",
  "static/chunks/[root-of-the-server]__1e52033c._.js",
  "static/chunks/styles_TermsOfService_module_e35b96fb.css",
  "static/chunks/pages_terms-of-service_5771e187._.js",
  "static/chunks/pages_terms-of-service_ca87360e._.js"
])
