module.exports = {

"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[project]/data/widgets.json (json)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v(JSON.parse("[{\"id\":1,\"title\":\"Dodgeball\",\"color\":\"bg-orange-500\",\"emoji\":\"🏐\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-2\"},{\"id\":2,\"title\":\"WhatsApp\",\"color\":\"bg-green-500\",\"emoji\":\"💬\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-2\"},{\"id\":3,\"title\":\"Schedule\",\"color\":\"bg-white text-black\",\"emoji\":\"📅\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-2\"},{\"id\":4,\"title\":\"Clinic Info\",\"color\":\"bg-white text-black\",\"emoji\":\"📋\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-4\"},{\"id\":5,\"title\":\"Discord\",\"color\":\"bg-indigo-600\",\"emoji\":\"💻\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-2\"},{\"id\":6,\"title\":\"Pricing\",\"color\":\"bg-orange-400\",\"emoji\":\"💳\",\"col\":\"col-span-6 md:col-span-8 lg:col-span-6\",\"row\":\"row-span-2\"},{\"id\":7,\"title\":\"Stats\",\"color\":\"bg-purple-500\",\"emoji\":\"📈\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-2\"},{\"id\":8,\"title\":\"Coach\",\"color\":\"bg-blue-600\",\"emoji\":\"🧑‍🏫\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-2\"},{\"id\":9,\"title\":\"Shop\",\"color\":\"bg-pink-500\",\"emoji\":\"🛍️\",\"col\":\"col-span-6 md:col-span-8 lg:col-span-6\",\"row\":\"row-span-2\"},{\"id\":10,\"title\":\"Photos\",\"color\":\"bg-yellow-400\",\"emoji\":\"📸\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-2\"},{\"id\":11,\"title\":\"FAQs\",\"color\":\"bg-gray-200 text-black\",\"emoji\":\"❓\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-4\"},{\"id\":12,\"title\":\"Contact\",\"color\":\"bg-blue-300\",\"emoji\":\"📞\",\"col\":\"col-span-6 md:col-span-8 lg:col-span-6\",\"row\":\"row-span-2\"},{\"id\":13,\"title\":\"Stats\",\"color\":\"bg-purple-500\",\"emoji\":\"📈\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-2\"},{\"id\":14,\"title\":\"Coach\",\"color\":\"bg-blue-600\",\"emoji\":\"🧑‍🏫\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-2\"},{\"id\":15,\"title\":\"Shop\",\"color\":\"bg-pink-500\",\"emoji\":\"🛍️\",\"col\":\"col-span-6 md:col-span-8 lg:col-span-6\",\"row\":\"row-span-2\"},{\"id\":16,\"title\":\"Photos\",\"color\":\"bg-yellow-400\",\"emoji\":\"📸\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-2\"},{\"id\":17,\"title\":\"FAQs\",\"color\":\"bg-gray-200 text-black\",\"emoji\":\"❓\",\"col\":\"col-span-6 md:col-span-4 lg:col-span-3\",\"row\":\"row-span-4\"},{\"id\":18,\"title\":\"Contact\",\"color\":\"bg-blue-300\",\"emoji\":\"📞\",\"col\":\"col-span-6 md:col-span-8 lg:col-span-6\",\"row\":\"row-span-2\"}]"));}}),
"[project]/components/Widget.jsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Widget)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
;
function Widget({ col, row, innerRef, children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: innerRef,
        className: `bento-tile ${col} ${row} bg-white shadow-md rounded-4xl overflow-hidden`,
        children: children
    }, void 0, false, {
        fileName: "[project]/components/Widget.jsx",
        lineNumber: 3,
        columnNumber: 5
    }, this);
}
}}),
"[project]/app/page.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>HomePage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$gsap$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/gsap/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$widgets$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/data/widgets.json (json)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Widget$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Widget.jsx [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
function HomePage() {
    const [visibleCount, setVisibleCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(6);
    const loadMoreRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const tileRefs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])([]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const el = tileRefs.current[visibleCount - 1];
        if (el) {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$gsap$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].fromTo(el, {
                opacity: 0,
                y: 30
            }, {
                opacity: 1,
                y: 0,
                duration: 1.2,
                ease: 'power3.out'
            });
        }
    }, [
        visibleCount
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!loadMoreRef.current || visibleCount >= __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$widgets$2e$json__$28$json$29$__["default"].length) return;
        const observer = new IntersectionObserver((entries)=>{
            if (entries[0].isIntersecting) {
                setVisibleCount((prev)=>Math.min(prev + 1, __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$widgets$2e$json__$28$json$29$__["default"].length));
            }
        }, {
            rootMargin: '200px'
        });
        observer.observe(loadMoreRef.current);
        return ()=>observer.disconnect();
    }, [
        visibleCount
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "container min-h-screen bg-[#f5e2cf] text-black px-20 lg:px-96 py-8  lg:py-48",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid grid-cols-6 md:grid-cols-8 lg:grid-cols-12 auto-rows-[72px] gap-4 grid-flow-dense max-w-screen-xl mx-auto",
            children: [
                __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$widgets$2e$json__$28$json$29$__["default"].slice(0, visibleCount).map((w, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Widget$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        title: w.title,
                        emoji: w.emoji,
                        color: w.color,
                        col: w.col,
                        row: w.row,
                        innerRef: (el)=>tileRefs.current[i] = el
                    }, w.id, false, {
                        fileName: "[project]/app/page.js",
                        lineNumber: 49,
                        columnNumber: 11
                    }, this)),
                visibleCount < __TURBOPACK__imported__module__$5b$project$5d2f$data$2f$widgets$2e$json__$28$json$29$__["default"].length && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    ref: loadMoreRef,
                    className: "col-span-12 h-1"
                }, void 0, false, {
                    fileName: "[project]/app/page.js",
                    lineNumber: 61,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/page.js",
            lineNumber: 47,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/page.js",
        lineNumber: 46,
        columnNumber: 5
    }, this);
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__b309bf05._.js.map