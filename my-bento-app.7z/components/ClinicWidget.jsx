'use client'

export default function ClinicWidget() {
  return (
    <iframe
      src="/widgets/clinic.html"
      className="w-full h-full rounded-3xl overflow-hidden"
      loading="lazy"
    />
  )
}
