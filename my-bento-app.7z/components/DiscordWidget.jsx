'use client'

export default function DiscordWidget() {
  return (
    <iframe
      src="/widgets/discord.html"
      className="w-full h-full rounded-3xl overflow-hidden"
      loading="lazy"
    />
  )
}
