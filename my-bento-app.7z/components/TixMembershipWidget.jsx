"use client";

export default function TixMembershipWidget() {
  return (
    <iframe
      src="../widgets/tix.html"
      className="w-full h-full rounded-3xl overflow-hidden"
      loading="lazy"
    />
  );
}
